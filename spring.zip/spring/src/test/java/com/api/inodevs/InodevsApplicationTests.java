package com.api.inodevs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InodevsApplicationTests {

	@Test
	void contextLoads() {
	}

}
